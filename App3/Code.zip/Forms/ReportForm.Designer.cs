﻿namespace App3.Forms
{
    partial class ReportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.MonCompBox = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.serviceCompBox = new System.Windows.Forms.ComboBox();
            this.classifityBox = new System.Windows.Forms.CheckBox();
            this.autoCompleteTextbox2 = new App3.Class.AutoCompleteTextbox();
            this.autoCompleteTextbox1 = new App3.Class.AutoCompleteTextbox();
            this.autoCompleteTextbox6 = new App3.Class.AutoCompleteTextbox();
            this.customerBox = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.objectBox = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.districtBox = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtFinish = new System.Windows.Forms.DateTimePicker();
            this.dtStart = new System.Windows.Forms.DateTimePicker();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.totalReport = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.statusReport = new System.Windows.Forms.RadioButton();
            this.ProcessingStat = new System.Windows.Forms.RadioButton();
            this.ProcessingList = new System.Windows.Forms.RadioButton();
            this.dynamicReport = new System.Windows.Forms.RadioButton();
            this.classifytyReport = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox1.Controls.Add(this.MonCompBox);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.serviceCompBox);
            this.groupBox1.Controls.Add(this.classifityBox);
            this.groupBox1.Controls.Add(this.autoCompleteTextbox2);
            this.groupBox1.Controls.Add(this.autoCompleteTextbox1);
            this.groupBox1.Controls.Add(this.autoCompleteTextbox6);
            this.groupBox1.Controls.Add(this.customerBox);
            this.groupBox1.Controls.Add(this.checkBox7);
            this.groupBox1.Controls.Add(this.checkBox6);
            this.groupBox1.Controls.Add(this.checkBox5);
            this.groupBox1.Controls.Add(this.objectBox);
            this.groupBox1.Controls.Add(this.checkBox4);
            this.groupBox1.Controls.Add(this.checkBox3);
            this.groupBox1.Controls.Add(this.checkBox2);
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Controls.Add(this.treeView1);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.districtBox);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.dtFinish);
            this.groupBox1.Controls.Add(this.dtStart);
            this.groupBox1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(651, 376);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Параметры отчета";
            // 
            // MonCompBox
            // 
            this.MonCompBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MonCompBox.Enabled = false;
            this.MonCompBox.FormattingEnabled = true;
            this.MonCompBox.Location = new System.Drawing.Point(51, 144);
            this.MonCompBox.Name = "MonCompBox";
            this.MonCompBox.Size = new System.Drawing.Size(260, 28);
            this.MonCompBox.TabIndex = 21;
            this.MonCompBox.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(52, 121);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(214, 20);
            this.label9.TabIndex = 20;
            this.label9.Text = "Мониторинговая компания";
            this.label9.Visible = false;
            // 
            // serviceCompBox
            // 
            this.serviceCompBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.serviceCompBox.Enabled = false;
            this.serviceCompBox.FormattingEnabled = true;
            this.serviceCompBox.Location = new System.Drawing.Point(361, 144);
            this.serviceCompBox.Name = "serviceCompBox";
            this.serviceCompBox.Size = new System.Drawing.Size(260, 28);
            this.serviceCompBox.TabIndex = 19;
            this.serviceCompBox.Visible = false;
            // 
            // classifityBox
            // 
            this.classifityBox.AutoSize = true;
            this.classifityBox.Location = new System.Drawing.Point(20, 203);
            this.classifityBox.Name = "classifityBox";
            this.classifityBox.Size = new System.Drawing.Size(15, 14);
            this.classifityBox.TabIndex = 18;
            this.classifityBox.UseVisualStyleBackColor = true;
            // 
            // autoCompleteTextbox2
            // 
            this.autoCompleteTextbox2.CaseSensitive = false;
            this.autoCompleteTextbox2.Enabled = false;
            this.autoCompleteTextbox2.Location = new System.Drawing.Point(361, 85);
            this.autoCompleteTextbox2.MinTypedCharacters = 2;
            this.autoCompleteTextbox2.Name = "autoCompleteTextbox2";
            this.autoCompleteTextbox2.SelectedIndex = -1;
            this.autoCompleteTextbox2.Size = new System.Drawing.Size(260, 26);
            this.autoCompleteTextbox2.TabIndex = 17;
            this.autoCompleteTextbox2.Visible = false;
            // 
            // autoCompleteTextbox1
            // 
            this.autoCompleteTextbox1.CaseSensitive = false;
            this.autoCompleteTextbox1.Enabled = false;
            this.autoCompleteTextbox1.Location = new System.Drawing.Point(361, 38);
            this.autoCompleteTextbox1.MinTypedCharacters = 2;
            this.autoCompleteTextbox1.Name = "autoCompleteTextbox1";
            this.autoCompleteTextbox1.SelectedIndex = -1;
            this.autoCompleteTextbox1.Size = new System.Drawing.Size(260, 26);
            this.autoCompleteTextbox1.TabIndex = 17;
            this.autoCompleteTextbox1.Visible = false;
            // 
            // autoCompleteTextbox6
            // 
            this.autoCompleteTextbox6.CaseSensitive = false;
            this.autoCompleteTextbox6.Enabled = false;
            this.autoCompleteTextbox6.Location = new System.Drawing.Point(51, 38);
            this.autoCompleteTextbox6.MinTypedCharacters = 2;
            this.autoCompleteTextbox6.Name = "autoCompleteTextbox6";
            this.autoCompleteTextbox6.SelectedIndex = -1;
            this.autoCompleteTextbox6.Size = new System.Drawing.Size(260, 26);
            this.autoCompleteTextbox6.TabIndex = 17;
            // 
            // customerBox
            // 
            this.customerBox.AutoSize = true;
            this.customerBox.Location = new System.Drawing.Point(332, 92);
            this.customerBox.Name = "customerBox";
            this.customerBox.Size = new System.Drawing.Size(15, 14);
            this.customerBox.TabIndex = 16;
            this.customerBox.UseVisualStyleBackColor = true;
            this.customerBox.Visible = false;
            this.customerBox.CheckedChanged += new System.EventHandler(this.customerBox_CheckedChanged);
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(332, 151);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(15, 14);
            this.checkBox7.TabIndex = 16;
            this.checkBox7.UseVisualStyleBackColor = true;
            this.checkBox7.Visible = false;
            this.checkBox7.CheckedChanged += new System.EventHandler(this.checkBox7_CheckedChanged);
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(20, 151);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(15, 14);
            this.checkBox6.TabIndex = 16;
            this.checkBox6.UseVisualStyleBackColor = true;
            this.checkBox6.Visible = false;
            this.checkBox6.CheckedChanged += new System.EventHandler(this.checkBox6_CheckedChanged);
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(20, 92);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(15, 14);
            this.checkBox5.TabIndex = 16;
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // objectBox
            // 
            this.objectBox.AutoSize = true;
            this.objectBox.Location = new System.Drawing.Point(332, 45);
            this.objectBox.Name = "objectBox";
            this.objectBox.Size = new System.Drawing.Size(15, 14);
            this.objectBox.TabIndex = 16;
            this.objectBox.UseVisualStyleBackColor = true;
            this.objectBox.Visible = false;
            this.objectBox.CheckedChanged += new System.EventHandler(this.objectBox_CheckedChanged);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(20, 45);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(15, 14);
            this.checkBox4.TabIndex = 16;
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Checked = true;
            this.checkBox3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox3.Location = new System.Drawing.Point(511, 263);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(106, 24);
            this.checkBox3.TabIndex = 15;
            this.checkBox3.Text = "Отключен";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Checked = true;
            this.checkBox2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox2.Location = new System.Drawing.Point(511, 233);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(102, 24);
            this.checkBox2.TabIndex = 15;
            this.checkBox2.Text = "Контроль";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Location = new System.Drawing.Point(511, 203);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(101, 24);
            this.checkBox1.TabIndex = 15;
            this.checkBox1.Text = "Работает";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // treeView1
            // 
            this.treeView1.CheckBoxes = true;
            this.treeView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.treeView1.Location = new System.Drawing.Point(51, 197);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(440, 134);
            this.treeView1.TabIndex = 14;
            this.treeView1.AfterCheck += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterCheck);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(362, 121);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(213, 20);
            this.label8.TabIndex = 8;
            this.label8.Text = "Обслуживающая компания";
            this.label8.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(362, 67);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 20);
            this.label7.TabIndex = 8;
            this.label7.Text = "Заказчик";
            this.label7.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(65, 175);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(131, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Классификатор";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(362, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(170, 20);
            this.label6.TabIndex = 8;
            this.label6.Text = "Объект мониторинга";
            this.label6.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(62, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(185, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "Абонентский комплект";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(65, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "Район";
            // 
            // districtBox
            // 
            this.districtBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.districtBox.Enabled = false;
            this.districtBox.FormattingEnabled = true;
            this.districtBox.Location = new System.Drawing.Point(51, 85);
            this.districtBox.Name = "districtBox";
            this.districtBox.Size = new System.Drawing.Size(260, 28);
            this.districtBox.TabIndex = 5;
            this.districtBox.SelectedIndexChanged += new System.EventHandler(this.districtBox_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(345, 339);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "ПО";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(18, 339);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(17, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "С";
            // 
            // dtFinish
            // 
            this.dtFinish.Location = new System.Drawing.Point(379, 337);
            this.dtFinish.Name = "dtFinish";
            this.dtFinish.Size = new System.Drawing.Size(242, 26);
            this.dtFinish.TabIndex = 3;
            // 
            // dtStart
            // 
            this.dtStart.Location = new System.Drawing.Point(52, 337);
            this.dtStart.Name = "dtStart";
            this.dtStart.Size = new System.Drawing.Size(242, 26);
            this.dtStart.TabIndex = 3;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(282, 478);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(114, 30);
            this.button2.TabIndex = 2;
            this.button2.Text = "Отмена";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(160, 477);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(116, 30);
            this.button1.TabIndex = 1;
            this.button1.Text = "Построить отчет";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // totalReport
            // 
            this.totalReport.AutoSize = true;
            this.totalReport.Checked = true;
            this.totalReport.Location = new System.Drawing.Point(12, 21);
            this.totalReport.Name = "totalReport";
            this.totalReport.Size = new System.Drawing.Size(162, 20);
            this.totalReport.TabIndex = 0;
            this.totalReport.TabStop = true;
            this.totalReport.Text = "Состояние объектов";
            this.totalReport.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(651, 514);
            this.panel1.TabIndex = 3;
            this.panel1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseClick);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox2.Controls.Add(this.statusReport);
            this.groupBox2.Controls.Add(this.totalReport);
            this.groupBox2.Controls.Add(this.ProcessingStat);
            this.groupBox2.Controls.Add(this.ProcessingList);
            this.groupBox2.Controls.Add(this.dynamicReport);
            this.groupBox2.Controls.Add(this.classifytyReport);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox2.Location = new System.Drawing.Point(0, 376);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(651, 96);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Вид отчета";
            // 
            // statusReport
            // 
            this.statusReport.AutoSize = true;
            this.statusReport.Location = new System.Drawing.Point(224, 21);
            this.statusReport.Name = "statusReport";
            this.statusReport.Size = new System.Drawing.Size(147, 20);
            this.statusReport.TabIndex = 1;
            this.statusReport.Text = "Статусы объектов";
            this.statusReport.UseVisualStyleBackColor = true;
            // 
            // ProcessingStat
            // 
            this.ProcessingStat.AutoSize = true;
            this.ProcessingStat.Location = new System.Drawing.Point(276, 70);
            this.ProcessingStat.Name = "ProcessingStat";
            this.ProcessingStat.Size = new System.Drawing.Size(208, 20);
            this.ProcessingStat.TabIndex = 0;
            this.ProcessingStat.Text = "Число сработок (за период)";
            this.ProcessingStat.UseVisualStyleBackColor = true;
            // 
            // ProcessingList
            // 
            this.ProcessingList.AutoSize = true;
            this.ProcessingList.Location = new System.Drawing.Point(12, 70);
            this.ProcessingList.Name = "ProcessingList";
            this.ProcessingList.Size = new System.Drawing.Size(215, 20);
            this.ProcessingList.TabIndex = 0;
            this.ProcessingList.Text = "Список сработок (за период)";
            this.ProcessingList.UseVisualStyleBackColor = true;
            // 
            // dynamicReport
            // 
            this.dynamicReport.AutoSize = true;
            this.dynamicReport.Location = new System.Drawing.Point(12, 45);
            this.dynamicReport.Name = "dynamicReport";
            this.dynamicReport.Size = new System.Drawing.Size(240, 20);
            this.dynamicReport.TabIndex = 0;
            this.dynamicReport.Text = "Состояние объектов (за период)";
            this.dynamicReport.UseVisualStyleBackColor = true;
            // 
            // classifytyReport
            // 
            this.classifytyReport.AutoSize = true;
            this.classifytyReport.Location = new System.Drawing.Point(469, 21);
            this.classifytyReport.Name = "classifytyReport";
            this.classifytyReport.Size = new System.Drawing.Size(129, 20);
            this.classifytyReport.TabIndex = 0;
            this.classifytyReport.Text = "Классификатор";
            this.classifytyReport.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.reportViewer1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(175, 514);
            this.panel2.TabIndex = 4;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reportViewer1.DocumentMapWidth = 3;
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(175, 514);
            this.reportViewer1.TabIndex = 0;
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.splitContainer1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.panel1);
            this.splitContainer1.Panel1MinSize = 0;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.panel2);
            this.splitContainer1.Panel2MinSize = 150;
            this.splitContainer1.Size = new System.Drawing.Size(846, 514);
            this.splitContainer1.SplitterDistance = 651;
            this.splitContainer1.SplitterWidth = 20;
            this.splitContainer1.TabIndex = 1;
            this.splitContainer1.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.splitContainer1_SplitterMoved);
            this.splitContainer1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.splitContainer1_MouseClick);
            this.splitContainer1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.splitContainer1_MouseDoubleClick);
            // 
            // ReportForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(846, 514);
            this.Controls.Add(this.splitContainer1);
            this.Name = "ReportForm";
            this.Text = "Мастер отчетов";
            this.Load += new System.EventHandler(this.ReportForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox districtBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtFinish;
        private System.Windows.Forms.DateTimePicker dtStart;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RadioButton totalReport;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TreeView treeView1;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private Class.AutoCompleteTextbox autoCompleteTextbox6;
        private System.Windows.Forms.RadioButton statusReport;
        private System.Windows.Forms.RadioButton dynamicReport;
        private System.Windows.Forms.RadioButton classifytyReport;
        private System.Windows.Forms.CheckBox classifityBox;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label label5;
        private Class.AutoCompleteTextbox autoCompleteTextbox1;
        private Class.AutoCompleteTextbox autoCompleteTextbox2;
        private System.Windows.Forms.CheckBox customerBox;
        private System.Windows.Forms.CheckBox objectBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox MonCompBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox serviceCompBox;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton ProcessingStat;
        private System.Windows.Forms.RadioButton ProcessingList;
    }
}