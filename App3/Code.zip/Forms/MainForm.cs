﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections.Specialized;
using App3.Class;
using OKOGate;
using App3.Dialogs;
using App3.Class.Static;
using MessageGroupId = App3.Class.Utils.MessageGroupId;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms.DataVisualization.Charting;
using App3.Forms.Dialog;
using App3.Forms.Object;

namespace App3.Forms
{
    public partial class MainForm : Form
    {
        private StartForm sf;

        public const int FORM_TOP_OFFSET = 113;
        public const int FORM_BORDER_WIDTH = 10;

        public delegate int NodeConnected(string sIpAddress);
        public NodeConnected NodeConnectedHandle = null;

        private Module oModule;

        private int ChildFormNumber = 0;
        // Формы
        private MessForm oEventsForm;
        private ConfigForm oConfigForm;
        private DBEvents oDBEvents;
        private MapForm oMap;
        private DistrictMap oDistricts;
        private TableEditForm oMessagesText;
        private ObjectForm oObjectForm;
        private WarningForm oWarnMonitor;
        private GlobalStat oGlobalStatistic;
        private Objects oObjectList;

        private bool isShowEventForm = false;

        public void SetStatusText(string pText)
        {
            toolStripStatusLabel.Text = pText;
        }

        private void SetChildFormsPosition()
        {
            oEventsForm.Top = this.Height - oEventsForm.Height - FORM_TOP_OFFSET;
            oEventsForm.Width = this.Width - 2 * FORM_BORDER_WIDTH;
        }

        private void StartOkoGate()
        {
            // OkoConnection.CleanCounters();
            
            oModule = new Module();
            oModule.LogLevel = Tracer.eLogLevel.DEBUG;
            oModule.Protocol = Module.PROTOCOL.XML_GUARD;

            oModule.RemotePort = Config.Get("ModuleRemotePort").ToInt();
            oModule.LocalServerIP = Config.Get("ModuleLocalServerIP");
            oModule.LocalServerPort = Config.Get("ModuleLocalServerPort").ToInt();
            oModule.LocalGUID = Config.Get("ModuleLocalGUID");
            oModule.ModuleId = Config.Get("ModuleModuleId").ToInt();

            oModule.RestoreConnectionTime = 5;
            oModule.GetModuleMessageEvent += ReciveMessage;
            oModule.StartModule();
            oModule.StartReceive();

            Handling.GetMessageEvent += OnGetMessage;

            Handling.onObjectCardOpen += OnObjectCardOpen;
            Handling.onObjectListOpen += OnObjectListOpen;
        }

        private void OnObjectListOpen(string Filter)
        {
            int top = 100;
            int left = 100;
            if (oObjectList != null && oObjectList.IsHandleCreated)
            {
                top = oObjectList.Top;
                left = oObjectList.Left;
            }
            else
            {
                oObjectList = new Objects(this);
                oObjectList.Show();
            }
            oObjectList.Top = top;
            oObjectList.Left = left;
            oObjectList.Focus();
            if (Filter != "")
            {
                oObjectList.Invoke(new Action(() => { oObjectList.SetFilter(Filter); }));
            }
        }

        private void OnObjectCardOpen(long pIdObject)
        {
            int top = 100;
            int left = 100;
            if (oObjectForm != null && oObjectForm.IsHandleCreated)
            {
                top = oObjectForm.Top;
                left = oObjectForm.Left;
            }
            else
            {
                oObjectForm = new ObjectForm(this);
                oObjectForm.Show();
            }
            oObjectForm.Top = top;
            oObjectForm.Left = left;
            oObjectForm.Focus();
            oObjectForm.Invoke(new Action(() => { oObjectForm.DBLoad(pIdObject); }));
        }

        private void StopOkoGate()
        {
            try
            {
                oModule.StopReceive();
                oModule.StopModule();
            } 
            catch
            {

            }
        }

        private void ReciveMessage(object arg)
        {
            OKOGate.Message msg = (OKOGate.Message)arg;
            if (msg.Text.IndexOf("?xml") > 0)
            {
                if (msg.Content == null)
                {
                    msg.Content = System.Text.Encoding.Default.GetBytes(
                        Utils.CutPrefixRec(msg.Text) // отрезаем то, что не относится к XML
                    );
                }
                msg.Text = System.Text.Encoding.Default.GetString(msg.Content);
                if (msg.Address != "" && NodeConnectedHandle != null)
                {
                    string str = NodeConnectedHandle(msg.Address).ToString();
                    if (ConnectCnt.InvokeRequired)
                    {
                        ConnectCnt.Invoke(new Action(() => { ConnectCnt.Text = str; }));
                    }
                    else
                    {
                        ConnectCnt.Text = str;
                    }
                }

                if (XMLReader.MessagePacker.Unpack(msg))
                {
                    switch (msg.Type)
                    {
                        case "MAIN_HEADER_XGUARD_OKOGATE":
                            break;
                        case "ACK_CONNECT_OKOGATE": // пришла квитанция
                            OkoConnection.FixCounterError(msg.Text);
                            break;
                        case "MESSAGE_PULT_OKOGATE": // пришло событие
                            Handling.ProcessingEvent(msg);
                            break;
                        case "ADD_OBJECT_XGUARD_OKOGATE": // добавление/изменение карточки объекта
                            MessageBox.Show("добавление/изменение карточки объекта");
                            break;
                        case "DEL_OBJECT_XGUARD_OKOGATE": // удаление объекта
                            MessageBox.Show("удаление объекта");
                            break;
                        case "USER_ACTION_XGUARD_OKOGATE": // действие по тревоге
                            MessageBox.Show("действие по тревоге");
                            break;
                        case "TEST_CONNECT_OKOGATE": // контроль канала связи
                            MessageBox.Show("контроль канала связи");
                            break;
                    }
                }
                else
                {
                    switch (msg.Type)
                    {
                        case "DEBUG_DRV_OKOGATE":
                            // Handling.ProcessingDbgEvent(msg);
                            OkoConnection.PushSystemId(msg.Text);
                            break;
                    }
                }
            }
            // oEventsForm.AddMessageType(msg.Type);
            // oEventsForm.AddEvent(msg.Type, msg.Text);
        }

        /// <summary>
        /// Отображение/неотображение тревожного экрана
        /// </summary>
        /// <param name="pMsgGrId"></param>
        /// <param name="pObject"></param>
        /// <param name="pMsgTxt"></param>
        /// <param name="pIpAddress"></param>
        private void ShowWarning(int pEventId, MessageGroupId pMsgGrId, AKObject pObject, string pMsgTxt, string pPhone, string pTime)
        {
            ObjectState state = DBDict.TState[(int)pMsgGrId];

            if (state.Warn && !warnToolStrip.Checked)
            {
                // Тревожный Экран
                oWarnMonitor.AddRow(pEventId, pObject.Id, pObject.number, pObject.DistrictName, pObject.name, pMsgTxt, state.Status, pPhone, state.Color, pTime);
                oWarnMonitor.Invoke(new Action(() => ShowWarnMon(state.Music)));
            }
        }

        private void OnGetMessage(int pEventId, MessageGroupId pMsgGrId, AKObject pObject, string pMsgTxt, string pPhone, string pTime)
        {
            if (oDistricts != null)
            {
                ShowWarning(pEventId, pMsgGrId, pObject, pMsgTxt, pPhone, pTime);
                /*
                switch (pMsgGrId)
                {
                    case MessageGroupId.TREV_OHRAN:
                    case MessageGroupId.TREV_POGAR:
                    case MessageGroupId.NEISPRAVNO:
                    case MessageGroupId.CH_S: // ЧС
                        // if (oDistricts.OneDistrictMapOpened == pObject.RegionId)
                        {
                            
                        }
                        break;
                    case MessageGroupId.NORMA:
                        // active.Notify(ObjectNumber, MessText);
                        // TODO
                        break;
                    default:
                        break;
                }*/
            }
            oEventsForm.AddEvent(pObject.number.ToString(), pMsgTxt, pObject.Id);
        }

        /// <summary>
        /// Потокобезопасный метод установки фокуса на форму сообщений в БД
        /// </summary>
        public void DBEventsFocus()
        {
            if (InvokeRequired)
            {
                oDBEvents.BeginInvoke(new Action(() => { oDBEvents.Focus(); }));
            }
            else
            {
                oDBEvents.Focus();
            }
        }

        private void WarnMonitorFocus()
        {
            if (InvokeRequired)
            {
                oWarnMonitor.BeginInvoke(new Action(() => { oWarnMonitor.Focus(); }));
            }
            else
            {
                oWarnMonitor.Focus();
            }
        }

        public MainForm()
        {
            this.Visible = false;
            sf = Utils.CreateLoadThread();
            InitializeComponent();
            
            // открыть соединение с БД
            try
            {
                DataBase.OpenConnection(
                    string.Format(
                        "Server={0};Port={1};User Id={2};Password={3};Database={4};MaxPoolSize=40;",
                        Config.Get("DBServerHost"),
                        Config.Get("DBServerPort"),
                        Config.Get("DBUser"),
                        Config.Get("DBPassword"),
                        Config.Get("DBName")
                    ));
                SetStatusText("Система запущена");
            }
            catch (DataBaseConnectionErrorExcepion e)
            {
                MessageBox.Show("DataBasse: " + e.Message);
                SetStatusText("Соединение с БД не было установлено. Причина: " + e.Message);
            }
            catch(Exception e)
            {
                MessageBox.Show("Error: " + e.Message);
            }
            // справочники
            DBDict.Update();
            // окно событий
            oEventsForm = new MessForm(this);
            oEventsForm.Show();
            SetChildFormsPosition();

            oConfigForm = new ConfigForm(this);
            oDBEvents = new DBEvents(this);
            oMap = new MapForm(this);
            oMessagesText = new TableEditForm(this, "oko.message_text", "Справочник сообщений");
            oWarnMonitor = new WarningForm(this);
            
            // окошко статистики
            oGlobalStatistic = new GlobalStat();
            //
            oObjectList = new Objects(this);
            // запуск прослушки
            if (DBDict.Settings["START_XML_GUARD"].ToBool())
            {
                StartOkoGate();
            }
            // обновление статусов регионов
            DataBase.RunCommand("select oko.update_district_statuses()");
        }

        public void LoadStat()
        {
            oGlobalStatistic.LoadStat();
        }

        private void ShowNewForm(object sender, EventArgs e)
        {
            Form childForm = new Form();
            childForm.MdiParent = this;
            childForm.Text = "Window " + ChildFormNumber++;
            childForm.Show();
        }

        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // установка цвета формы
            MdiClient ctlMDI;
            foreach (Control ctl in this.Controls)
            {
                try
                {
                    ctlMDI = (MdiClient)ctl;
                    ctlMDI.BackColor = this.BackColor;
                }
                catch 
                {}
            }
            // события
            ShowDBEvents();
            // запуск формы с картой районов
            oDistricts = new DistrictMap(this);
            oDistricts.Show();
            //
            this.Visible = true;
            // this.Invoke(new Action(() => {this.Opacity = 100;}) );
            Utils.DestroyStartThread(sf);
        }

        private void MainForm_SizeChanged(object sender, EventArgs e)
        {
            SetChildFormsPosition();
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            StopOkoGate();
            DataBase.CloseConnection();
        }

        private void optionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowOption();
        }

        private void ShowOption()
        {
            // окно настроек
            if (!oConfigForm.Visible)
            {
                oConfigForm.Show();
            }
            oConfigForm.Focus();
        }

        private void ShowDBEvents()
        {
            if (!oDBEvents.Visible)
            {
                oDBEvents.Show();
            }
            oDBEvents.Focus();
        }

        private void ShowWarnMon(bool play)
        {
            if(!oWarnMonitor.Visible)
            {
                oWarnMonitor.Show();
            }
            WarnMonitorFocus();

            if (play)
            {
                oWarnMonitor.PlaySound();
            }
        }

        public void AddMapClickEvents(App3.Forms.MapForm.MapBoxClick pMethod)
        {
            oMap.AddClickEvents(pMethod);
        }

        private void ShowMap()
        {
            oMap.Show();
            oMap.Left = this.Width - oMap.Width - 20;
            oMap.Top = 0;
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            ShowOption();
        }

        private void событияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowDBEvents();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            ShowDBEvents();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Если приложение будет закрыто - на данном узле мониторинг событий будет остановлен. Завершить работу с программой?", "Выйти из программы", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                Close();
            }
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Вам отображена карта районов Ростовской области");
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ObjectForm objFrm = new ObjectForm(this);
            AddMapClickEvents(objFrm.MapBoxClick);
            objFrm.Show();
        }

        private void searchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SearchObject s = new SearchObject();
            s.OnSelectObject = new SearchObject.SelectObjectHandler(FoundedObject);
            oObjectForm = new ObjectForm(this);
            s.ShowDialog();
        }

        public void FoundedObject(Int64 object_id)
        {
            oObjectForm.Show(object_id);
        }

        private void MainForm_Resize(object sender, EventArgs e)
        {

        }

        public void ChangeDistrictScale(double Scale)
        {
            oDistricts.SetScale(Scale);
        }

        public void ShowDistrict(string DistrictName)
        {
            oDistricts.OpenOneDistrictForm(DistrictName);
        }

        private void ShowEventForm()
        {
            if (!isShowEventForm)
            {
                oEventsForm.Focus();
                oDistricts.Height = oDistricts.Height - oEventsForm.Height;
            }
            else
            {
                oDistricts.Height = oDistricts.Height + oEventsForm.Height;
                oDistricts.Focus();
                oDistricts.FocusOneDistrictForm();
            }
            isShowEventForm = !isShowEventForm;
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            ShowEventForm();
        }

        public void DistrictMapRefresh()
        {
            oDistricts.RefreshMaps();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            
        }

        private void ShowMessageEdit()
        {
            if (!oMessagesText.Visible)
            {
                oMessagesText.Show();
            }
            oMessagesText.Focus();
        }

        private void районыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TableEditForm frmEdit = new TableEditForm(this, "oko.ipaddresses", "Справочник IP-адресов");
            frmEdit.AddForeign("id_region", "regions2map", "num", "name");
            frmEdit.CanEdit = true;
            frmEdit.Show();
        }

        private void районыToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            TableEditForm frmEdit = new TableEditForm(this, "regions2map", "Справочник районов");
            frmEdit.CanAdd = false;
            frmEdit.CanDel = false;
            frmEdit.CanEdit = true;
            frmEdit.Show();
        }

        private void типыКонтактовToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TableEditForm frmEdit = new TableEditForm(this, "oko.tcontact", "Типы контактов");
            frmEdit.CanDel = false;
            frmEdit.CanEdit = true;
            frmEdit.Show();
        }

        
        private void очиститьКэшToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Очистка кэша потребует перезапуска программы. Вы действительно хотите выполнить перезапуск?", "Очистить кэш", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                Hide();
                GeoDataCache.ClearCache();
                Utils.restartApp();
            }
        }

        private void картаToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void ShowDiagramEvents()
        {
            panel1.Visible = !panel1.Visible;
            if (panel1.Visible)
            {
                oDistricts.Height = oDistricts.Height - panel1.Height;
                oEventsForm.Top = oEventsForm.Top - panel1.Height;
                UpdateDiagram();
            }
            else
            {
                oDistricts.Height = oDistricts.Height + panel1.Height;
                oEventsForm.Top = oEventsForm.Top + panel1.Height;
            }
        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            ShowDiagramEvents();
        }

        private void UpdateDiagram()
        {
            List<object[]> rows = DataBase.RowSelect(@"select t.mins, count(t.id) as cnt
                        from (
                        select 	case
	                        when DATE_PART('minute', now()) >= DATE_PART('minute', datetime) THEN
	                        DATE_PART('minute', now()) - DATE_PART('minute', datetime) 
	                        else 60 + DATE_PART('minute', now()) - DATE_PART('minute', datetime)
	                        end as mins, id
                        from oko.event
                        where (now() - datetime ) <  interval '55 minute'
                        ) t
                        group by t.mins
                        order by t.mins"
                );
            chart1.Series.Clear();
            chart1.Legends.Clear();
            var EventCols = new Series("EventCols");
            EventCols.ChartType = SeriesChartType.Column;
            chart1.Series.Add(EventCols);

            chart1.ChartAreas[0] = new ChartArea
            {
                BackColor = Color.Transparent,
                BorderColor = Color.FromArgb(240, 240, 240),
                BorderWidth = 1,
                BorderDashStyle = ChartDashStyle.Solid,
                AxisX = new Axis
                {
                    Enabled = AxisEnabled.True,
                    IntervalAutoMode = IntervalAutoMode.VariableCount,
                    IsLabelAutoFit = false,
                    IsMarginVisible = true,
                    Minimum = 0,
                    Maximum = 40,
                    LabelStyle = new LabelStyle 
                    { 
                        ForeColor = Color.FromArgb(100, 100, 100), 
                        Font = new Font("Arial", 6, FontStyle.Regular) 
                    },
                    LineColor = Color.FromArgb(220, 220, 220),
                    MajorGrid = new Grid { LineColor = Color.FromArgb(240, 240, 240), LineDashStyle = ChartDashStyle.Solid },
                    MajorTickMark = new TickMark { LineColor = Color.FromArgb(220, 220, 220), Size = 4.0f },
                },
                AxisY = new Axis
                {
                    Enabled = AxisEnabled.True,
                    IntervalAutoMode = IntervalAutoMode.VariableCount,
                    IsLabelAutoFit = false,
                    IsMarginVisible = true,
                    LabelStyle = new LabelStyle 
                    { 
                        ForeColor = Color.FromArgb(100, 100, 100), 
                        Font = new Font("Arial", 6, FontStyle.Regular) 
                    },
                    LineColor = Color.Transparent,
                    MajorGrid = new Grid { LineColor = Color.FromArgb(240, 240, 240), LineDashStyle = ChartDashStyle.Solid },
                    MajorTickMark = new TickMark { LineColor = Color.FromArgb(240, 240, 240), Size = 2.0f }
                },
                Position = new ElementPosition { Height = 100, Width = 100, X = 0, Y = 0 }
            };

            EventCols.IsVisibleInLegend = false;

            foreach (object[] row in rows)
            {
                EventCols.Points.Add(new DataPoint(row[0].ToDouble(), row[1].ToDouble()));
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            UpdateDiagram();
            label4.Text = (label4.Text.ToInt() + 1).ToString();
        }

        private void группыСообщенийToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowMessageEdit();
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (oWarnMonitor != null)
            {
                oWarnMonitor.Close();
            }
        }

        private void toolStripButton4_Click_1(object sender, EventArgs e)
        {
            if (!oGlobalStatistic.Visible)
            {
                oGlobalStatistic.Show();
                oGlobalStatistic.Left = 0;
                oGlobalStatistic.Top = 100;
            }
        }

        private void событийOnlineToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowEventForm();
        }

        private void графикСобытийToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowDiagramEvents();
        }

        private void иерархическийКлассификаторToolStripMenuItem_Click(object sender, EventArgs e)
        {
            (new ClassifierForm(true)).ShowDialog();
        }

        private void списокОбъектовToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // oObjectList.Show();
            Handling.onObjectListOpen("");
        }

        private void toolStripButton6_Click_1(object sender, EventArgs e)
        {
            ShowWarnMon(false);
        }

        private void отчетToolStripMenuItem_Click(object sender, EventArgs e)
        {
            (new ReportForm()).ShowDialog();
        }

        private void toolStripButton8_Click(object sender, EventArgs e)
        {
            UpdInsideSize();
        }

        private void UpdInsideSize()
        {
            this.WindowState = FormWindowState.Maximized;
            oDistricts.UpdSize();

            SetChildFormsPosition();

            if (panel1.Visible)
            {
                panel1.Visible = false;
                ShowDBEvents();
            }
            if (isShowEventForm)
            {
                isShowEventForm = false;
                ShowEventForm();
            }
        }

        private void объектыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TableEditForm frmEdit = new TableEditForm("oko.real_object", "Справочник объектов");
            frmEdit.CanAdd = false;
            frmEdit.CanDel = true;
            frmEdit.CanEdit = true;
            frmEdit.ShowDialog();
            DBDict.UpdateDictionary("TRealObject");
        }

        private void заказчикиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TableEditForm frmEdit = new TableEditForm("oko.customer", "Справочник заказчиков");
            frmEdit.CanAdd = false;
            frmEdit.CanDel = true;
            frmEdit.CanEdit = true;
            frmEdit.ShowDialog();
            DBDict.UpdateDictionary("TCustomer");
        }

        private void toolStripButton9_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void организацииToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TableEditForm frmEdit = new TableEditForm("oko.company", "Справочник компаний");
            frmEdit.CanAdd = true;
            frmEdit.CanDel = true;
            frmEdit.CanEdit = true;
            frmEdit.ShowDialog();
            DBDict.UpdateDictionary("TCompany");
        }
    }
}
