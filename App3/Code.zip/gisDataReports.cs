﻿namespace App3 {
    
    
    public partial class gisDataReports {
    }
}
